public class TestBlockchain {

	public static void main(String args[]) {
		
		Blockmainchain tcpCoin = new Blockmainchain();
		
		MainBlock a = new MainBlock("0x200", new java.util.Date(), "<transactions>");
		MainBlock b = new MainBlock("0x200", new java.util.Date(), "<transactions>");
		MainBlock c = new MainBlock("0x200", new java.util.Date(), "<transactions>");
		
		tcpCoin.addBlock(a);
		tcpCoin.addBlock(b);
		tcpCoin.addBlock(c);
		
		//tcpCoin.getLatestBlock().setPreviousHash("ABCDEFG");
		
		tcpCoin.displayChain();
		
		tcpCoin.isValid();

	}
	
}
